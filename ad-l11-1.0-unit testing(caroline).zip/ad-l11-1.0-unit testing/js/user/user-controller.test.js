const UserController = require("./user-controller");
const User = require("./user");

const userController = new UserController();

test('add user to userController', () => {    
    let user = new User(1234,"Santiago", "santiago@generation.org");
    userController.add(user);    
    expect(userController.getUsers()).toContain(user);
  });

test('remove user to userController', () => {    
    let user = new User(1234,"Santiago", "santiago@generation.org");
    userController.add(user);    
    userController.remove(user);
    expect(userController.users).not.toContain(user);
  });

 
  
  test('add() should add a user to the users list', () => {
    const userController = new UserController();
    const user = new User(1, 'John Doe', 'john@example.com');
    userController.add(user);
    expect(userController.getUsers()).toContain(user);
  });
  
  test('remove() should remove a user from the users list', () => {
    const userController = new UserController();
    const user = new User(1, 'John Doe', 'john@example.com');
    userController.add(user);
    userController.remove(user);
    expect(userController.getUsers()).not.toContain(user);
  });
  
  test('findByEmail() should return the correct user', () => {
    const userController = new UserController();
    const user = new User(1, 'John Doe', 'john@example.com');
    userController.add(user);
    expect(userController.findByEmail('john@example.com')).toBe(user);
  });
  
  test('findByEmail() should return undefined for non-existent email', () => {
    const userController = new UserController();
    expect(userController.findByEmail('nonexistent@example.com')).toBeUndefined();
  });
  
  test('findById() should return the correct user', () => {
    const userController = new UserController();
    const user = new User(1, 'John Doe', 'john@example.com');
    userController.add(user);
    expect(userController.findById(1)).toBe(user);
  });
  
  test('findById() should return undefined for non-existent id', () => {
    const userController = new UserController();
    expect(userController.findById(999)).toBeUndefined();
  });
  